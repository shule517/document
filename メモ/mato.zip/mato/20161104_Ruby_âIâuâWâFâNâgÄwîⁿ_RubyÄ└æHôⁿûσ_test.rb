WebPush�@�\�����






class Gear
  initialize(x, y, z, w)
    @x = x
    @y = y
    @z = z
    @w = w
  end
end

class Wheel
  attr_reader x, y
  initialize(x, y)
    @x = x
    @y = y
  end

  def detemiter
  end
end

gear = Gear.new(1, 2, 3, 4)
gear.detemer


gear = Gear.new(1, 2, Wheel.new(3, 4))
gear.detemiter



class Gear
  initialize(x, y, wheel)
    @x = x
    @y = y
    @wheel = wheel
  end

  def detemiter
    
  end
end

class Wheel
  attr_reader x, y
  initialize(x, y)
    @x = x
    @y = y
  end

  def detemiter
  end
end
