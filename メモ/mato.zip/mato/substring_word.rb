class String
  def substring_word(start, length)
    # 半角のみの場合
    return self[start, length] unless has_mb?

    # マルチバイトを含む場合
    count = 0
    result = ''
    self.each_char do |char|
      result += char if count >= start
      count += char.bytesize > 1 ? 2 : 1 # 全角は長さ2として扱う
      return result if count >= (start + length)
    end
    result
  end

  def has_mb?
    @has_mb ||= begin
      self.each_byte do |b|
        return true if (b & 0b10000000) != 0
      end
      false
    end
  end
end
